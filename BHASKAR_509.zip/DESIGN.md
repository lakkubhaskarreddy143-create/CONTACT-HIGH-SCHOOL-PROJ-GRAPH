# Design Explanation: Link Prediction (Lab Exam 3)

## Problem
Graph G(V,E): 327 students, 5,818 friendships (undirected, unweighted, no self or
multiple edges). Rank the 47,483 non-existent edges (U - E, where |U| = 327*326/2 = 53,301)
with two scores and output the top K for each.

## Data structure
Adjacency lists: `adj[v]` is a sorted list of the neighbours of `v` (nodes are labelled 1..327).
Duplicates / self edges are removed while loading (a set of `(min,max)` pairs); the weight is ignored.
Memory is O(|V|+|E|). Sets of neighbours are built only for fast intersection / membership tests.

## Enumerating U - E
For each u, for each v > u, keep the pair if v is not in N(u). Each pair appears once.

## Jaccard's coefficient
JC(u,v) = |N(u) ∩ N(v)| / |N(u) ∪ N(v)|, with |A∪B| = |A|+|B|-|A∩B|.
If the union is empty (both isolated) the score is 0. Cost: O(min(d(u),d(v))) per pair on average.

## Katz score (beta = 0.1, l = 2..6)
KS(u,v) = sum over l=2..6 of beta^l * (number of length-l connections between u and v).

Method (BFS-like level expansion): for one source u keep `cur[x]` = number of ways to reach x
in exactly l steps. To go to l+1, push every count along every edge x-y. After 6 levels we have
the counts for all targets v at once. This costs O(L*|E|) per source, O(|V|*L*|E|) overall
(about 2*10^7 operations), so the whole run takes about a second.

### Important note: walks vs simple paths
The question says "paths of length exactly l" (no repeated vertex). Enumerating all simple
paths of length 6 by DFS is infeasible here (about 10^9 paths per source node, so about 10^12 in total).
The level expansion counts *walks* (vertices may repeat). Facts:
* For non-adjacent u,v, walks = simple paths at l = 2 and l = 3 (exact).
* For l = 4,5,6 the walk count is an upper bound on the path count.
* I checked this on the real data: for 5 source nodes I computed the exact simple-path
  Katz scores with a C DFS (about 6 s per source) and compared the rankings with the walk-based
  ones. Rank correlation was 0.995 or higher, and 46 to 50 of the top 50 targets (out of 326) were common.
* `count_simple_paths_dfs` is the exact DFS version; it is used in the tests on small graphs.

## Ranking and output
Sort by score descending; ties are broken by smaller node ids, so output is deterministic.
Each output line is `u v score`. Files: `Jaccard.txt`, `Katz.txt`.

## Complexity summary
| Step | Time |
|------|------|
| Load graph | O(\|E\|) |
| Jaccard, all non-edges | about O(\|V\|^2 * avg degree) |
| Katz, all non-edges | O(\|V\| * L * \|E\|) |
| Sorting | O(M log M), M = 47,483 |

## Test cases (`test_link_prediction.py`)
Loading (adjacency lists, duplicates, self edges, real dataset counts), non-edge enumeration,
hand-computed Jaccard values, isolated nodes, hand-computed Katz on the path 1-2-3,
walks = paths for l=2,3, walks >= paths, and correct descending order.
