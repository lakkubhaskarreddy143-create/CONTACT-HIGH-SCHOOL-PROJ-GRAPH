"""Test cases for link_prediction.py   (run: python test_link_prediction.py)"""
import os, tempfile, unittest
import link_prediction as lp


def make_graph(edge_list):
    """Write edges to a temp file in 'i j w' format and load them."""
    with tempfile.NamedTemporaryFile("w", delete=False, suffix=".txt") as f:
        for a, b in edge_list:
            f.write(f"{a} {b} 7\n")        # weight 7 must be ignored
        name = f.name
    try:
        return lp.load_graph(name)
    finally:
        os.remove(name)


class TestLoading(unittest.TestCase):
    def test_adjacency_lists(self):
        adj, n = make_graph([(1, 2), (2, 3), (3, 1)])
        self.assertEqual(n, 3)
        self.assertEqual(adj[1], [2, 3])
        self.assertEqual(adj[2], [1, 3])

    def test_duplicates_and_self_edges_removed(self):
        adj, n = make_graph([(1, 2), (2, 1), (1, 2), (2, 2)])
        self.assertEqual(adj[1], [2])
        self.assertEqual(adj[2], [1])

    def test_non_edges(self):
        adj, n = make_graph([(1, 2), (2, 3), (3, 4)])
        self.assertEqual(sorted(lp.non_edges(adj, n)), [(1, 3), (1, 4), (2, 4)])

    def test_real_dataset(self):
        p = "contact-high-school-proj-graph.txt"
        if os.path.exists(p):
            adj, n = lp.load_graph(p)
            self.assertEqual(n, 327)
            self.assertEqual(sum(len(a) for a in adj) // 2, 5818)


class TestJaccard(unittest.TestCase):
    def setUp(self):
        # 1-2, 1-3, 2-4, 3-4, 4-5 : non-edges (1,4),(2,3),(1,5),(2,5),(3,5)
        self.adj, self.n = make_graph([(1, 2), (1, 3), (2, 4), (3, 4), (4, 5)])
        self.sets = [set(a) for a in self.adj]

    def test_values(self):
        # N(1)={2,3}, N(4)={2,3,5}: inter 2, union 3
        self.assertAlmostEqual(lp.jaccard_score(self.sets, 1, 4), 2 / 3)
        # N(2)={1,4}, N(3)={1,4}: inter 2, union 2
        self.assertAlmostEqual(lp.jaccard_score(self.sets, 2, 3), 1.0)
        # N(1)={2,3}, N(5)={4}: no common neighbour
        self.assertEqual(lp.jaccard_score(self.sets, 1, 5), 0.0)

    def test_ranking(self):
        top = lp.rank(lp.jaccard_all(self.adj, self.n))[0]
        self.assertEqual((top[1], top[2]), (2, 3))

    def test_isolated_nodes_no_division_by_zero(self):
        adj = [[], [], [], []]            # 3 nodes, no edges
        sets = [set(a) for a in adj]
        self.assertEqual(lp.jaccard_score(sets, 1, 2), 0.0)


class TestKatz(unittest.TestCase):
    def test_path_graph_hand_computed(self):
        # path 1-2-3: only non-edge is (1,3). Walks 1->3: l=2: 1 (1-2-3).
        # l=3: 0 (graph is bipartite, parity). l=4: 1 (1-2-1-2-3)... counted as walk.
        adj, n = make_graph([(1, 2), (2, 3)])
        walks = lp.walk_counts_from(adj, n, 1)
        self.assertEqual(walks[2][3], 1)
        self.assertEqual(walks[3][3], 0)
        self.assertEqual(walks[4][3], 2)  # 1-2-1-2-3 and 1-2-3-2-3
        score = [s for s, u, v in lp.katz_all(adj, n) if (u, v) == (1, 3)][0]
        expected = 0.1**2 * 1 + 0.1**4 * 2 + 0.1**6 * 4
        self.assertAlmostEqual(score, expected)

    def test_walks_equal_paths_for_length_2_and_3(self):
        """For NON-adjacent pairs, walks and simple paths coincide at l=2,3."""
        adj, n = make_graph([(1, 2), (1, 3), (2, 4), (3, 4), (4, 5), (2, 5), (3, 6), (5, 6)])
        for u, v in lp.non_edges(adj, n):
            walks = lp.walk_counts_from(adj, n, u)
            for l in (2, 3):
                self.assertEqual(walks[l][v], lp.count_simple_paths_dfs(adj, u, v, l))

    def test_dfs_exact_paths(self):
        # square 1-2-3-4-1: between 1 and 3 there are 2 paths of length 2
        adj, n = make_graph([(1, 2), (2, 3), (3, 4), (4, 1)])
        self.assertEqual(lp.count_simple_paths_dfs(adj, 1, 3, 2), 2)
        self.assertEqual(lp.count_simple_paths_dfs(adj, 1, 3, 3), 0)

    def test_walk_score_is_upper_bound_of_path_score(self):
        adj, n = make_graph([(1, 2), (1, 3), (2, 4), (3, 4), (4, 5), (2, 5), (3, 6), (5, 6)])
        for u, v in lp.non_edges(adj, n):
            walks = lp.walk_counts_from(adj, n, u)
            for l in range(2, 7):
                self.assertGreaterEqual(walks[l][v], lp.count_simple_paths_dfs(adj, u, v, l))

    def test_ranking_order(self):
        adj, n = make_graph([(1, 2), (2, 3), (1, 4), (4, 3), (3, 5)])
        r = lp.rank(lp.katz_all(adj, n))
        scores = [x[0] for x in r]
        self.assertEqual(scores, sorted(scores, reverse=True))


if __name__ == "__main__":
    unittest.main(verbosity=2)
