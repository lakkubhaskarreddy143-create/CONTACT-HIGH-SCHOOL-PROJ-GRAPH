"""
Lab Exam 3 - Link Prediction (Jaccard's coefficient and Katz score)

Usage:
    python link_prediction.py                 # asks for K
    python link_prediction.py 50              # K = 50
    python link_prediction.py 50 other.txt    # K = 50, different input file

Outputs (same directory as this script's working directory):
    Jaccard.txt   top-K non-existent edges by Jaccard coefficient
    Katz.txt      top-K non-existent edges by Katz score (beta = 0.1)

No graph libraries are used. Only the Python standard library (sys, os).
"""

import sys

BETA = 0.1        # Katz decay factor
MAX_LEN = 6       # Katz uses path lengths 2 .. MAX_LEN


# ----------------------------------------------------------------------
# PART 1: reading the graph and storing it as adjacency lists
# ----------------------------------------------------------------------
def load_graph(filename):
    """
    Read lines of the form "i j w". The weight w is ignored (treated as 1).
    Self edges and repeated edges are skipped so the graph is simple.

    Returns (adj, n):
        adj[v] = sorted list of neighbours of v   (index 0 is unused)
        n      = number of nodes (largest node label; labels are 1..n)
    """
    edges = set()                       # set of (small, big) pairs removes duplicates
    max_node = 0
    with open(filename) as f:
        for line in f:
            parts = line.split()
            if len(parts) < 2:          # skip blank lines
                continue
            a, b = int(parts[0]), int(parts[1])
            if a == b:                  # no self edges allowed
                continue
            edges.add((a, b) if a < b else (b, a))
            max_node = max(max_node, a, b)

    adj = [[] for _ in range(max_node + 1)]
    for a, b in edges:                  # undirected: store in both lists
        adj[a].append(b)
        adj[b].append(a)
    for v in range(max_node + 1):
        adj[v].sort()
    return adj, max_node


def non_edges(adj, n):
    """
    Generate every pair (u, v), u < v, that is NOT an edge (the set U - E).
    A set of neighbours is used only for fast membership testing.
    """
    for u in range(1, n + 1):
        nbrs = set(adj[u])
        for v in range(u + 1, n + 1):
            if v not in nbrs:
                yield (u, v)


# ----------------------------------------------------------------------
# PART 2a: Jaccard's coefficient
# ----------------------------------------------------------------------
def jaccard_score(adj_sets, u, v):
    """JC(u,v) = |N(u) & N(v)| / |N(u) | N(v)|.  Returns 0 if both are isolated."""
    nu, nv = adj_sets[u], adj_sets[v]
    inter = len(nu & nv)
    union = len(nu) + len(nv) - inter   # |A u B| = |A| + |B| - |A n B|
    return inter / union if union else 0.0


def jaccard_all(adj, n):
    """Return list of (score, u, v) for every non-edge."""
    adj_sets = [set(a) for a in adj]
    return [(jaccard_score(adj_sets, u, v), u, v) for u, v in non_edges(adj, n)]


# ----------------------------------------------------------------------
# PART 2b: Katz score
# ----------------------------------------------------------------------
def walk_counts_from(adj, n, s, max_len=MAX_LEN):
    """
    Level-by-level (BFS-like) expansion from source s.
    cur[x] = number of walks of length l that go from s to x.
    Next level: every walk ending at x is extended along every edge x-y.
    Returns walks[l] (a list indexed by node) for l = 0 .. max_len.
    """
    cur = [0] * (n + 1)
    cur[s] = 1
    walks = [cur]
    for _ in range(max_len):
        nxt = [0] * (n + 1)
        for x in range(1, n + 1):
            c = cur[x]
            if c:
                for y in adj[x]:
                    nxt[y] += c
        walks.append(nxt)
        cur = nxt
    return walks


def katz_all(adj, n, beta=BETA, max_len=MAX_LEN):
    """
    KS(u,v) = sum_{l=2..max_len} beta^l * (number of length-l connections u..v)
    Returns list of (score, u, v) for every non-edge (u < v).
    One expansion per source u is enough: it gives scores to all v at once.
    """
    result = []
    for u in range(1, n + 1):
        walks = walk_counts_from(adj, n, u, max_len)
        nbrs = set(adj[u])
        for v in range(u + 1, n + 1):
            if v in nbrs:               # existing edge, not a candidate
                continue
            score = 0.0
            for l in range(2, max_len + 1):
                score += (beta ** l) * walks[l][v]
            result.append((score, u, v))
    return result


def count_simple_paths_dfs(adj, s, t, length):
    """
    EXACT number of simple paths (no repeated vertex) of exactly `length`
    edges from s to t, using DFS with a visited set (backtracking).
    Too slow for the full dataset at length 6 (billions of paths), so it is
    used for the test cases and for validating the fast method on small graphs.
    """
    visited = {s}

    def dfs(x, depth):
        if depth == length:
            return 1 if x == t else 0
        total = 0
        for y in adj[x]:
            if y not in visited:
                visited.add(y)
                total += dfs(y, depth + 1)
                visited.remove(y)
        return total

    return dfs(s, 0)


# ----------------------------------------------------------------------
# Ranking and output
# ----------------------------------------------------------------------
def rank(scored):
    """Sort by score (high to low); ties broken by smaller node ids first."""
    return sorted(scored, key=lambda t: (-t[0], t[1], t[2]))


def write_top_k(filename, ranked, k, fmt):
    with open(filename, "w") as f:
        for score, u, v in ranked[:k]:
            f.write(f"{u} {v} {format(score, fmt)}\n")


def main():
    k = int(sys.argv[1]) if len(sys.argv) > 1 else int(input("Enter K: "))
    path = sys.argv[2] if len(sys.argv) > 2 else "contact-high-school-proj-graph.txt"

    adj, n = load_graph(path)
    m = sum(len(a) for a in adj) // 2
    print(f"Nodes: {n}, edges: {m}, non-edges: {n * (n - 1) // 2 - m}")

    write_top_k("Jaccard.txt", rank(jaccard_all(adj, n)), k, ".6f")
    print("Wrote Jaccard.txt")
    write_top_k("Katz.txt", rank(katz_all(adj, n)), k, ".6f")
    print("Wrote Katz.txt")


if __name__ == "__main__":
    main()
